package com.gkv.newbie.app.home.sections.user;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.gkv.newbie.R;

public class UpdateUserActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_user);
    }
}