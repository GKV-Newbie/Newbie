package com.gkv.newbie.app.home.sections.user;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.gkv.newbie.R;
import com.gkv.newbie.app.home.BaseNavigationActivity;

public class SearchUserActivity extends BaseNavigationActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_user);
    }
}