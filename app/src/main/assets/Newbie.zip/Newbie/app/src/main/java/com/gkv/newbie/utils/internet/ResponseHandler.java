package com.gkv.newbie.utils.internet;

public abstract class ResponseHandler {

    public abstract void onCallback(String response);

}
