package com.gkv.newbie;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        System.out.println(FirebaseAuth.getInstance().getApp().toString());
        startActivity(new Intent(this, PermissionCheckActivity.class));
    }
}
