package com.gkv.newbie.utils.favourites;

import android.os.Environment;

import java.io.File;
import java.util.ArrayList;

public class FavouriteManager {

    private static FavouriteManager instance;

    private File rootDirectory;

    private FavouriteManager(){
        rootDirectory = new File(Environment.getDataDirectory(),"favourites");
        rootDirectory.mkdirs();
    }

    public static FavouriteManager getInstance() {
        if(instance==null)
            instance = new FavouriteManager();
        return instance;
    }

    public ArrayList<String> getFavouritesList(){
        ArrayList<String> list = new ArrayList<>();
        for(String str:rootDirectory.list()){
            list.add(str);
        }
        return list;
    }

    public void addToFavouritesList(String email){
        new File(rootDirectory,email).mkdirs();
    }

    public void removeFromFavouritesList(String email){
        new File(rootDirectory,email).delete();
    }

    public boolean existsInFavouritesList(String email){
        return new File(rootDirectory,email).exists();
    }

}
